﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Collections;


namespace Tools
{
    class xml_handler
    {

        private String file_name = "";
        private String page = "";
        private String attr = "";
        //=============================================================================
        //xml_handler mem = new xml_handler("Settings.ini", "SpikeChecker", "magnitude");
        //f_path = mem.get_str("Last_Program_Loaded_Path");
        //_________________________________________________________________________________________________________
        public static bool Fill_with_object(String path, string f_name, TreeView tv)
        {
            tv.Nodes.Clear();
            XmlDocument doc = new XmlDocument();
            try
            {
                doc.Load(Path.Combine(path, f_name));
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.ToString());
                return false;
            }
            XmlNodeList aNodes = doc.SelectNodes("/" + "OBJECT" + "//*");

            int count = 0;
            foreach (XmlNode aNode in aNodes)
            {
                if (count == 0)
                {
                    TreeNode treenode = tv.Nodes.Add("Object", aNode.Name);
                    count = populateChildNodes(aNode, treenode);
                }
                else
                {
                    count--;
                }
            }
            tv.Update();
            tv.Refresh();
            return true;
        }
        //_________________________________________________________________________________________________________
        public static bool Fill_with_object(string f_name, TreeView tv)
        {
            tv.Nodes.Clear();
            XmlDocument doc = new XmlDocument();
            try
            {
                doc.Load(f_name);
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.ToString());
                return false;
            }
            XmlNodeList aNodes = doc.SelectNodes("/" + "OBJECT" + "//*");

            int count = 0;
            foreach (XmlNode aNode in aNodes)
            {
                if (count == 0)
                {
                    TreeNode treenode = tv.Nodes.Add("Object", aNode.Name);
                    count = populateChildNodes(aNode, treenode);
                }
                else
                {
                    count--;
                }
            }
            tv.Update();
            tv.Refresh();
            return true;
        }
        //_________________________________________________________________________________________________________

        public static int populateChildNodes(XmlNode oldXmlnode, TreeNode oldTreenode)
        {
            int count;
            TreeNode treenode = null;
            XmlNodeList childNodeList = oldXmlnode.ChildNodes;
            count = childNodeList.Count;
            foreach (XmlNode xmlnode in childNodeList)
            {
                string title = xmlnode.Name;
                treenode = oldTreenode.Nodes.Add(title);
            }
            return count;
        }
        //_________________________________________________________________________________________________________
        public xml_handler(String f_name, String page, String attr)
        {
            this.file_name = f_name;
            this.page = page;
            this.attr = attr;
        }
        //==============================================================================
        //public String Read_data()
        //{

        //    string doc = "c:\\firstXML.xml";

        //    XmlTextReader reader = null;

        //    // Load the file with an XmlTextReader
        //    reader = new XmlTextReader(doc);

        //    // Read the File
        //    if (File.Exists(doc))
        //    {
        //        while (reader.Read())
        //        {
        //            if (reader.NodeType == XmlNodeType.Element && reader.Name == "ComboBox1")
        //            {
        //                //checking where read text is element and and name is “ComboBox1”
        //                string strCmb1 = reader.ReadElementString();
        //                //assigning ReadElementstring to strCmb1.
        //                if (strCmb1 == "Red")
        //                    textBox1.BackColor = Color.Red;
        //                else if (strCmb1 == "Blue")
        //                    textBox1.BackColor = Color.Blue;
        //                else if (strCmb1 == "Green")
        //                    textBox1.BackColor = Color.Green;
        //                else
        //                    textBox1.BackColor = Color.Yellow;
        //                //changing backcolor of text box according to the XML file data.
        //            }
        //            if (reader.NodeType == XmlNodeType.Element && reader.Name == "ComboBox2")
        //            {
        //                string strCmb2 = reader.ReadElementString();
        //                if (strCmb2 == "Red")
        //                    textBox2.BackColor = Color.Red;
        //                else if (strCmb2 == "Blue")
        //                    textBox2.BackColor = Color.Blue;
        //                else if (strCmb2 == "Green")
        //                    textBox2.BackColor = Color.Green;
        //                else
        //                    textBox2.BackColor = Color.Yellow;
        //            }
        //            if (reader.NodeType == XmlNodeType.Element && reader.Name == "ComboBox3")
        //            {
        //                string strCmb3 = reader.ReadElementString();
        //                if (strCmb3 == "Red")
        //                    textBox3.BackColor = Color.Red;
        //                else if (strCmb3 == "Blue")
        //                    textBox3.BackColor = Color.Blue;
        //                else if (strCmb3 == "Green")
        //                    textBox3.BackColor = Color.Green;
        //                else
        //                    textBox3.BackColor = Color.Yellow;
        //            }

        //        }
        //        reader.Close();
        //    }

        //}




        //    return "s";
        //}

        //=====================================================================================
        //public bool put(String param, String data)
        //{


        //    XmlDocument doc = new XmlDocument();
        //    XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
        //    doc.AppendChild(docNode);

        //    XmlNode live_Page = doc.CreateElement("Live_Page");
        //    doc.AppendChild(live_Page);



        //    XmlNode node_voltage = doc.CreateElement("voltage");
        //    XmlAttribute attr_vol = doc.CreateAttribute("magnitude");
        //    attr_vol.Value = "180.00";
        //    node_voltage.Attributes.Append(attr_vol);
        //    live_Page.AppendChild(node_voltage);


        //    XmlNode node_current = doc.CreateElement("Current");
        //    XmlAttribute attr_cur = doc.CreateAttribute("magnitude");
        //    attr_cur.Value = "120A";
        //    node_current.Attributes.Append(attr_cur);
        //    live_Page.AppendChild(node_current);


        //    //XmlNode alertNode = doc.CreateElement("Alert");
        //    //XmlAttribute alertAttribute = doc.CreateAttribute("id"); alertAttribute.Value = "01";
        //    //alertNode.Attributes.Append(alertAttribute);
        //    //live_Page.AppendChild(alertNode);

        //    //XmlNode alertNode2 = doc.CreateElement("Alert2");
        //    //XmlAttribute alert2Attribute = doc.CreateAttribute("id2"); alert2Attribute.Value = "02";
        //    //alertNode2.Attributes.Append(alert2Attribute);
        //    //live_Page.AppendChild(alertNode2);

        //    //XmlNode nameNode = doc.CreateElement("Name");
        //    //nameNode.AppendChild(doc.CreateTextNode("Java"));
        //    //productNode.AppendChild(nameNode);
        //    //XmlNode priceNode = doc.CreateElement("Price");
        //    //priceNode.AppendChild(doc.CreateTextNode("Free"));
        //    //productNode.AppendChild(priceNode);


        //    string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
        //    doc.Save(Path.Combine(folder2, "settings.ini")); // GOOD









        //    //XmlDocument xmlDoc = new XmlDocument();
        //    //XmlNode root = xmlDoc.DocumentElement;
        //    ////creating child nodes.
        //    //XmlElement childNode1 = xmlDoc.CreateElement("ComboBox1");
        //    //XmlElement childNode2 = xmlDoc.CreateElement("ComboBox2");
        //    //XmlElement childNode3 = xmlDoc.CreateElement("ComboBox3");

        //    ////adding child node to root.
        //    //root.AppendChild(childNode1);
        //    //childNode1.InnerText = "comboBox1.Text";
        //    ////assigning innertext of childnode to text of combobox.
        //    //root.AppendChild(childNode2);
        //    //childNode2.InnerText = "comboBox2.Text";
        //    //root.AppendChild(childNode3);
        //    //childNode3.InnerText = "comboBox3.Text";

        //    ////    xmlDoc.Save(filename);

        //    //string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
        //    //xmlDoc.Save(Path.Combine(folder2, "settings.ini")); // GOOD


        //    //// Create and add another product node.
        //    //productNode = doc.CreateElement("product");
        //    //productAttribute = doc.CreateAttribute("id");
        //    //productAttribute.Value = "02";
        //    //productNode.Attributes.Append(productAttribute);
        //    //productsNode.AppendChild(productNode);
        //    //nameNode = doc.CreateElement("Name");
        //    //nameNode.AppendChild(doc.CreateTextNode("C#"));
        //    //productNode.AppendChild(nameNode);
        //    //priceNode = doc.CreateElement("Price");
        //    //priceNode.AppendChild(doc.CreateTextNode("Free"));
        //    //productNode.AppendChild(priceNode);








        //    //string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
        //    //// Create the XmlDocument.
        //    //XmlDocument doc = new XmlDocument();
        //    //doc.LoadXml("grid"); //Your string here

        //    //// Save the document to a file and auto-indent the output.
        //    //XmlTextWriter writer = new XmlTextWriter(folder2, null);
        //    //writer.Formatting = Formatting.Indented;
        //    //doc.Save(writer);




        //    //try
        //    //{

        //    //    string filename = "c:\\firstXML.xml";
        //    //    XmlDocument xmlDoc = new XmlDocument();
        //    //    XmlTextWriter xmlWriter = new XmlTextWriter(filename, System.Text.Encoding.UTF8);
        //    //    xmlWriter.WriteStartDocument(true);
        //    //    xmlWriter.Formatting = Formatting.Indented;
        //    //    xmlWriter.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");
        //    //    xmlWriter.WriteStartElement("Employee");
        //    //    xmlWriter.Close();
        //    //    //closing writer

        //    //    xmlDoc.Load(filename);
        //    //    //loading XML file

        //    //    XmlNode root = xmlDoc.DocumentElement;
        //    //    //creating child nodes.
        //    //    XmlElement childNode1 = xmlDoc.CreateElement("ComboBox1");
        //    //    XmlElement childNode2 = xmlDoc.CreateElement("ComboBox2");
        //    //    XmlElement childNode3 = xmlDoc.CreateElement("ComboBox3");

        //    //    //adding child node to root.
        //    //    root.AppendChild(childNode1);
        //    //    childNode1.InnerText = "comboBox1.Text";
        //    //    //assigning innertext of childnode to text of combobox.
        //    //    root.AppendChild(childNode2);
        //    //    childNode2.InnerText = "comboBox2.Text";
        //    //    root.AppendChild(childNode3);
        //    //    childNode3.InnerText = "comboBox3.Text";

        //    //    xmlDoc.Save(filename);
        //    //    //saving xml file
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    return false;
        //    //}

        //    return true;
        //}//PutSettings(String param, String data)
        ////============================================================================
        public String get_all_Nodes()
        {
            List<string> cities = new List<string>();
            cities.Add("New York");
            cities.Add("Mumbai");
            try
            {
                XmlDocument doc = new XmlDocument();

                string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                doc.Load(Path.Combine(folder2, this.file_name));

                XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "//*");

                //   XmlNodeList aNodes = doc.SelectNodes("//*");

                foreach (XmlNode aNode in aNodes)
                {
                    XmlAttribute idAttribute = aNode.Attributes[this.attr];
                    String s = aNode.Name;
                }
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return "";
        }
        //==========================================================================
        ///
        public String get_str(String param)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                doc.Load(Path.Combine(folder2, this.file_name));

                XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

                foreach (XmlNode aNode in aNodes)
                {
                    XmlAttribute idAttribute = aNode.Attributes[this.attr];
                    String s = idAttribute.Value;
                    return s;
                }
            }catch(Exception ex)
            {
                String s = ex.ToString();
            }

                return "";
        }
        //==========================================================================
        public double get_double(String param)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                doc.Load(Path.Combine(folder2, this.file_name));

                XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

                foreach (XmlNode aNode in aNodes)
                {
                    XmlAttribute idAttribute = aNode.Attributes[this.attr];
                    String s = idAttribute.Value;
                    return Convert.ToDouble(s);
                }
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return 0;
        }
        //==========================================================================
        public String get_str(string file_name,String param)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                //  string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                //  doc.Load(Path.Combine(folder2, this.file_name));
                doc.Load(file_name);

                XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

                foreach (XmlNode aNode in aNodes)
                {
                    XmlAttribute idAttribute = aNode.Attributes[this.attr];
                    String s = idAttribute.Value;
                    return s;
                }
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return "";
        }
        //==========================================================================





        public bool get(String param)
        {
            XmlDocument doc = new XmlDocument();

            string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            doc.Load(Path.Combine(folder2, this.file_name));

            XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute idAttribute = aNode.Attributes[this.attr];
                return  Convert.ToBoolean(idAttribute.Value);
            }
            return false;
        }
        //==========================================================================
        public UInt16 get_Uint16(String param)
        {
            XmlDocument doc = new XmlDocument();

            string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            doc.Load(Path.Combine(folder2, this.file_name));

            XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute idAttribute = aNode.Attributes[this.attr];
                return Convert.ToUInt16(idAttribute.Value);
            }
            return 0;
        }
        //==========================================================================
        public Int32 get_Int32(String param)
        {
            XmlDocument doc = new XmlDocument();

            string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            doc.Load(Path.Combine(folder2, this.file_name));

            XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param);

            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute idAttribute = aNode.Attributes[this.attr];
                return Convert.ToInt32(idAttribute.Value);
            }
            return 0;
        }
        //==========================================================================
        public bool put(String param,String val)
        {
            XmlDocument doc = new XmlDocument();

            string folder2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            doc.Load(Path.Combine(folder2,this.file_name));

            XmlNodeList aNodes = doc.SelectNodes("/" + this.page + "/" + param); 

            foreach (XmlNode aNode in aNodes)
            {
                XmlAttribute idAttribute = aNode.Attributes[this.attr];
                idAttribute.Value = val;

                doc.Save(Path.Combine(folder2, this.file_name));
                return true; 
            }
            return false;
        }
        //==========================================================================

    }
}