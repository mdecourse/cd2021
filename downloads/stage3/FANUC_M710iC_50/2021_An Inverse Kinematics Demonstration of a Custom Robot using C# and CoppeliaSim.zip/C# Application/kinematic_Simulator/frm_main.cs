﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tools;

namespace kinematic_Simulator
{
    public partial class frm_main : Form
    {
        CoppeliaBlueRobot rbt = new CoppeliaBlueRobot();
        xml_handler mem = new xml_handler("Settings.ini", "IK_Simulator", "magnitude");

        double left_gpr_val = -0.5;
        double right_gpr_val =0;
        string Gripper_Status = "idle";
        public frm_main()
        {
            InitializeComponent();
        }
        //___________________________________________________________________________________________________________
        private void frm_main_Load(object sender, EventArgs e)
        {
            rbt.start();
            timer1.Interval = 1;
            timer1.Enabled = true;

            txt_TX.Text = mem.get_str("TX");
            txt_TY.Text = mem.get_str("TY");
            txt_TZ.Text = mem.get_str("TZ");
            txt_RX.Text = mem.get_str("RX");
            txt_RY.Text = mem.get_str("RY");
            txt_RZ.Text = mem.get_str("RZ");

            txt_left_gripper.Text= mem.get_str("Left_Gripper");
            txt_right_gripper.Text = mem.get_str("Right_Gripper");

            decimal d = Convert.ToDecimal(txt_TX.Text); d *= 100; hs_TX.Value =(int)d;
            d = Convert.ToDecimal(txt_TY.Text); d *= 100; hs_TY.Value = (int)d;
            d = Convert.ToDecimal(txt_TZ.Text); d *= 100; hs_TZ.Value = (int)d;
        }
        //______________________________________________________________________________________________________
        private void timer1_Tick(object sender, EventArgs e)
        {
            Gripper_Handler();
            rbt.push_IK_Data(  txt_TX.Text, txt_TY.Text, txt_TZ.Text, txt_RX.Text, txt_RY.Text, txt_RZ.Text,txt_left_gripper.Text,txt_right_gripper.Text);
            txt_msg.Text = rbt.bfr_RX;

            if (rbt.bfr_RX != "")
            {
                txt_j1.Text = utilString.Get_String_from_Exponent_string(rbt.bfr_RX, "J1=", ",", 2);
                txt_j2.Text = utilString.Get_String_from_Exponent_string(rbt.bfr_RX, "J2=", ",", 2);
                txt_j3.Text = utilString.Get_String_from_Exponent_string(rbt.bfr_RX, "J3=", ",", 2);
                txt_j4.Text = utilString.Get_String_from_Exponent_string(rbt.bfr_RX, "J4=", ",", 2);
                txt_j5.Text = utilString.Get_String_from_Exponent_string(rbt.bfr_RX, "J5=", ">", 2);
            }
        }
        //_________________________________________________________________________________________________________
        private void hs_TX_Scroll(object sender, ScrollEventArgs e)
        {
          
            txt_TX.Text = (hs_TX.Value/100.0).ToString();
        }
        //__________________________________________________________________________________________________________
        private void hs_TY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_TY.Text = (hs_TY.Value/100.0).ToString();
        }
        //________________________________________________________________________________________________________
        private void hs_TZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_TZ.Text = (hs_TZ.Value/100.0).ToString();
        }
        //________________________________________________________________________________________________________
        private void hs_RX_Scroll(object sender, ScrollEventArgs e)
        {
            txt_RX.Text = hs_RX.Value.ToString();
        }
        //__________________________________________________________________________________________________________
        private void hs_RY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_RY.Text = hs_RY.Value.ToString();
        }
        //______________________________________________________________________________________________________
        private void hs_RZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_RZ.Text = hs_RZ.Value.ToString();
        }
        //________________________________________________________________________________________________________
        private void frm_main_FormClosing(object sender, FormClosingEventArgs e)
        {
            rbt.stop();

            mem.put("TX", txt_TX.Text);
            mem.put("TY", txt_TY.Text);
            mem.put("TZ", txt_TZ.Text);

            mem.put("RX", txt_RX.Text);
            mem.put("RY", txt_RY.Text);
            mem.put("RZ", txt_RZ.Text);
        }

        private void btn_gripper_Open_Click(object sender, EventArgs e)
        {
            Gripper_Status = "Open";
        }

        private void btn_gripper_Close_Click(object sender, EventArgs e)
        {
            Gripper_Status = "Close";
        }
        //________________________________________________________________________________________________________
       private void Gripper_Handler()
        {
            double l_gripper = Convert.ToDouble(txt_left_gripper.Text);
            double r_gripper = Convert.ToDouble(txt_right_gripper.Text);

            switch (Gripper_Status)
            {
                case "idle":


                break;
                ///////////////
                case "Open":
                    l_gripper += 0.001;
                    if (l_gripper >= 0)
                    {
                        Gripper_Status = "idle";
                    }

                    r_gripper -= 0.001;
                    if (l_gripper >= 0)
                    {
                        Gripper_Status = "idle";
                    }

                    break;
                ///////////////
                case "Close":

                    l_gripper -= 0.001;
                    if (l_gripper <= -0.05)
                    {
                        Gripper_Status = "idle";
                    }

                    r_gripper += 0.001;
                    if (l_gripper >= 0.05)
                    {
                        Gripper_Status = "idle";
                    }                 

                    break;
                //////////////
                default:
                    break;
            }

            txt_left_gripper.Text = l_gripper.ToString();
            txt_right_gripper.Text = r_gripper.ToString();
        }
        //________________________________________________________________________________________________________





    }
}
